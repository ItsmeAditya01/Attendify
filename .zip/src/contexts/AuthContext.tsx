
import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { User, Session } from '@supabase/supabase-js';

interface UserProfile {
  id: string;
  email: string;
  role: 'student' | 'faculty' | 'admin';
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: UserProfile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, userData: any) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const createSimpleProfile = (user: User): UserProfile => {
    return {
      id: user.id,
      email: user.email || '',
      role: 'admin' // Default role for simplicity
    };
  };

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Initial session:', session);
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        setProfile(createSimpleProfile(session.user));
      }
      
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('Auth state changed:', event, session?.user?.email);
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setProfile(createSimpleProfile(session.user));
        } else {
          setProfile(null);
        }
        
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    console.log('Attempting sign in for:', email);
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    console.log('Sign in result:', error ? 'Error' : 'Success');
    return { error };
  };

  // const signUp = async (email: string, password: string, userData: any) => {
  //   console.log('Attempting sign up for:', email);
  //   const { error } = await supabase.auth.signUp({
  //     email,
  //     password,
  //   });

  //   console.log('Sign up result:', error ? 'Error' : 'Success');
  //   return { error };
  // };

  const signUp = async (email: string, password: string, userData: any) => {
  console.log('Attempting sign up for:', email);
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
                          // options: {
                          //   data: userData, // Store custom metadata like role
                          // },
  });

  console.log('Sign up result:', error ? 'Error' : 'Success');
  return { data, error };
};

  const signOut = async () => {
    console.log('Signing out...');
    await supabase.auth.signOut();
    setProfile(null);
  };

  const value = {
    user,
    session,
    profile,
    loading,
    signIn,
    signUp,
    signOut,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
