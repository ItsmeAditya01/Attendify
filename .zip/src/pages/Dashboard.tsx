
import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Users, 
  Calendar, 
  ClipboardList, 
  TrendingUp, 
  Bell,
  Settings,
  LogOut,
  Menu,
  UserPlus,
  BookOpen,
  BarChart3,
  CheckCircle,
  XCircle,
  Search
} from "lucide-react";
import { Sidebar } from "@/components/Sidebar";
import { UserManagement } from "@/components/UserManagement";
import { supabase } from "@/lib/supabase";

interface Student {
  id: string;
  name: string;
  enrollment_number: string;
  email: string;
  course: string;
  class: string;
  semester: number;
  attendance_percentage: number;
}

const Dashboard = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const role = searchParams.get('role') || 'student';
  const [activeSection, setActiveSection] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Attendance tab state
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterClass, setFilterClass] = useState("all");
  const [filterSemester, setFilterSemester] = useState("all");
  const [filterCourse, setFilterCourse] = useState("all");

  useEffect(() => {
    if (!role) {
      navigate('/');
    }
  }, [role, navigate]);

  useEffect(() => {
    if (activeSection === 'attendance') {
      fetchStudents();
    }
  }, [activeSection]);

  useEffect(() => {
    filterStudents();
  }, [students, searchTerm, filterClass, filterSemester, filterCourse]);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const { data: studentsData, error } = await supabase
        .from('students')
        .select('*');

      if (error) throw error;

      // Mock attendance percentages for now (in real app, this would come from attendance records)
      const studentsWithAttendance: Student[] = studentsData?.map(student => ({
        id: student.user_id,
        name: student.name,
        enrollment_number: student.enrollment_number,
        email: student.email,
        course: student.course || 'N/A',
        class: student.class || 'N/A',
        semester: student.semester || 1,
        attendance_percentage: Math.floor(Math.random() * 40) + 60 // Mock: 60-100%
      })) || [];

      setStudents(studentsWithAttendance);
    } catch (error) {
      console.error('Error fetching students:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterStudents = () => {
    let filtered = students;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(student => 
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.enrollment_number.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Class filter
    if (filterClass !== "all") {
      filtered = filtered.filter(student => student.class === filterClass);
    }

    // Semester filter
    if (filterSemester !== "all") {
      filtered = filtered.filter(student => student.semester.toString() === filterSemester);
    }

    // Course filter
    if (filterCourse !== "all") {
      filtered = filtered.filter(student => student.course === filterCourse);
    }

    setFilteredStudents(filtered);
  };

  const getUniqueValues = (key: keyof Student) => {
    return [...new Set(students.map(student => student[key]))].filter(Boolean);
  };

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilterClass("all");
    setFilterSemester("all");
    setFilterCourse("all");
  };

  const handleLogout = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar 
        role={role} 
        activeSection={activeSection} 
        onSectionChange={setActiveSection}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
      
      <div className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-16'}`}>
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 capitalize">
                  {role} Dashboard
                </h1>
                <p className="text-gray-600">Welcome back to Attendify</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-5 w-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="text-red-600 hover:text-red-700"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-6">
          {activeSection === 'overview' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Admin Overview</CardTitle>
                  <CardDescription>
                    Welcome to the Attendify Admin Dashboard. Use the sidebar to navigate between different sections.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Users className="h-8 w-8 text-blue-600" />
                        <div>
                          <h3 className="font-semibold text-blue-900">User Management</h3>
                          <p className="text-sm text-blue-700">Manage students and faculty</p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <ClipboardList className="h-8 w-8 text-green-600" />
                        <div>
                          <h3 className="font-semibold text-green-900">Attendance</h3>
                          <p className="text-sm text-green-700">View student attendance</p>
                        </div>
                      </div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <BarChart3 className="h-8 w-8 text-purple-600" />
                        <div>
                          <h3 className="font-semibold text-purple-900">Reports</h3>
                          <p className="text-sm text-purple-700">Generate reports</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSection === 'attendance' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <ClipboardList className="h-5 w-5 text-blue-600" />
                    <span>Student Attendance</span>
                  </CardTitle>
                  <CardDescription>
                    View and filter student attendance records across the institute
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Filters */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search by name or enrollment..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                    <Select value={filterClass} onValueChange={setFilterClass}>
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by Class" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        {getUniqueValues('class').map((cls) => (
                          <SelectItem key={cls} value={cls.toString()}>{cls}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={filterSemester} onValueChange={setFilterSemester}>
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by Semester" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Semesters</SelectItem>
                        {getUniqueValues('semester').map((sem) => (
                          <SelectItem key={sem} value={sem.toString()}>{sem}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={filterCourse} onValueChange={setFilterCourse}>
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by Course" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Courses</SelectItem>
                        {getUniqueValues('course').map((course) => (
                          <SelectItem key={course} value={course.toString()}>{course}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Clear Filters Button */}
                  {(searchTerm || filterClass !== "all" || filterSemester !== "all" || filterCourse !== "all") && (
                    <div className="mb-4">
                      <Button variant="outline" onClick={resetFilters}>
                        Clear Filters
                      </Button>
                    </div>
                  )}

                  {/* Students Table */}
                  {loading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                      <p>Loading students...</p>
                    </div>
                  ) : (
                    <div className="rounded-lg border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Enrollment No.</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead>Class</TableHead>
                            <TableHead>Semester</TableHead>
                            <TableHead>Attendance %</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredStudents.map((student) => (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">{student.enrollment_number}</TableCell>
                              <TableCell>{student.name}</TableCell>
                              <TableCell>{student.email}</TableCell>
                              <TableCell>{student.course}</TableCell>
                              <TableCell>{student.class}</TableCell>
                              <TableCell>{student.semester}</TableCell>
                              <TableCell className={`font-semibold ${getAttendanceColor(student.attendance_percentage)}`}>
                                {student.attendance_percentage}%
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      
                      {filteredStudents.length === 0 && (
                        <div className="text-center py-8 text-gray-500">
                          <ClipboardList className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                          <p>No students found matching your criteria</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {activeSection === 'users' && role === 'admin' && (
            <UserManagement />
          )}

          {activeSection === 'reports' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-blue-600" />
                    <span>Reports & Analytics</span>
                  </CardTitle>
                  <CardDescription>
                    Generate and view detailed attendance reports
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-gray-500">
                    <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p>Reporting features coming soon...</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
