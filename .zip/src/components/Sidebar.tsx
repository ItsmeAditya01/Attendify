
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  ClipboardList, 
  Users, 
  BarChart3, 
  GraduationCap,
  BookOpen,
  UserCheck
} from "lucide-react";

interface SidebarProps {
  role: string;
  activeSection: string;
  onSectionChange: (section: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function Sidebar({ role, activeSection, onSectionChange, isOpen }: SidebarProps) {
  const getMenuItems = () => {
    const commonItems = [
      { id: 'overview', label: 'Overview', icon: LayoutDashboard },
      { id: 'attendance', label: 'Attendance', icon: ClipboardList },
    ];

    const roleSpecificItems = {
      student: [
        { id: 'courses', label: 'My Courses', icon: BookOpen },
      ],
      faculty: [
        { id: 'classes', label: 'My Classes', icon: BookOpen },
        { id: 'students', label: 'Students', icon: UserCheck },
      ],
      admin: [
        { id: 'users', label: 'User Management', icon: Users },
        { id: 'reports', label: 'Reports', icon: BarChart3 },
      ]
    };

    return [...commonItems, ...(roleSpecificItems[role as keyof typeof roleSpecificItems] || [])];
  };

  const menuItems = getMenuItems();

  return (
    <div className={cn(
      "fixed left-0 top-0 z-40 h-full bg-white border-r border-gray-200 transition-all duration-300",
      isOpen ? "w-64" : "w-16"
    )}>
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            {isOpen && (
              <div>
                <h2 className="text-xl font-bold text-blue-900">Attendify</h2>
                <p className="text-xs text-gray-500 capitalize">{role} Portal</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant={activeSection === item.id ? "default" : "ghost"}
              className={cn(
                "w-full justify-start text-left",
                activeSection === item.id 
                  ? "bg-blue-600 text-white hover:bg-blue-700" 
                  : "text-gray-700 hover:bg-blue-50",
                !isOpen && "px-2"
              )}
              onClick={() => onSectionChange(item.id)}
            >
              <item.icon className={cn("h-5 w-5", isOpen ? "mr-3" : "mx-auto")} />
              {isOpen && <span>{item.label}</span>}
            </Button>
          ))}
        </nav>

        {/* User Info */}
        {isOpen && (
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-semibold text-sm">
                  {role.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 capitalize">
                  {role} User
                </p>
                <p className="text-xs text-gray-500 truncate">
                  {role}@university.edu
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
