// components/overview/FacultyOverview.tsx
import { StatsCards } from "./StatsCards";
import { RecentActivity } from "./RecentActivity";

export function FacultyOverview() {
  return (
    <div className="space-y-6">
      <StatsCards role="faculty" />
      {/* You can add a class-based chart or schedule component here */}
      <RecentActivity role="faculty" />
    </div>
  );
}
