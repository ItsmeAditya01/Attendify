
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";

interface RecentActivityProps {
  role: string;
}

export function RecentActivity({ role }: RecentActivityProps) {
  const getActivitiesForRole = () => {
    switch (role) {
      case 'student':
        return [
          {
            id: 1,
            title: "Marked present in Database Systems",
            time: "2 hours ago",
            status: "present",
            icon: CheckCircle
          },
          {
            id: 2,
            title: "Missed Software Engineering class",
            time: "1 day ago",
            status: "absent",
            icon: XCircle
          },
          {
            id: 3,
            title: "Marked present in Web Development",
            time: "2 days ago",
            status: "present",
            icon: CheckCircle
          },
          {
            id: 4,
            title: "Late arrival in Data Structures",
            time: "3 days ago",
            status: "late",
            icon: AlertCircle
          }
        ];
      
      case 'faculty':
        return [
          {
            id: 1,
            title: "Completed attendance for CS-301",
            time: "1 hour ago",
            status: "completed",
            icon: CheckCircle
          },
          {
            id: 2,
            title: "Started new class session",
            time: "3 hours ago",
            status: "active",
            icon: Clock
          },
          {
            id: 3,
            title: "Generated attendance report",
            time: "1 day ago",
            status: "completed",
            icon: CheckCircle
          },
          {
            id: 4,
            title: "Low attendance alert for CS-201",
            time: "2 days ago",
            status: "warning",
            icon: AlertCircle
          }
        ];
      
      case 'admin':
        return [
          {
            id: 1,
            title: "Added new faculty member",
            time: "30 minutes ago",
            status: "completed",
            icon: CheckCircle
          },
          {
            id: 2,
            title: "System backup completed",
            time: "2 hours ago",
            status: "completed",
            icon: CheckCircle
          },
          {
            id: 3,
            title: "Monthly report generated",
            time: "1 day ago",
            status: "completed",
            icon: CheckCircle
          },
          {
            id: 4,
            title: "Low attendance alert campus-wide",
            time: "2 days ago",
            status: "warning",
            icon: AlertCircle
          }
        ];
      
      default:
        return [];
    }
  };

  const activities = getActivitiesForRole();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
      case 'completed':
        return 'text-green-600 bg-green-50';
      case 'absent':
        return 'text-red-600 bg-red-50';
      case 'late':
      case 'warning':
        return 'text-orange-600 bg-orange-50';
      default:
        return 'text-blue-600 bg-blue-50';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'present':
        return 'Present';
      case 'absent':
        return 'Absent';
      case 'late':
        return 'Late';
      case 'completed':
        return 'Completed';
      case 'active':
        return 'Active';
      case 'warning':
        return 'Warning';
      default:
        return status;
    }
  };

  return (
    <Card className="border-0 shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Clock className="h-5 w-5 text-blue-600" />
          <span>Recent Activity</span>
        </CardTitle>
        <CardDescription>
          Latest updates and notifications
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
              <div className={`p-2 rounded-full ${getStatusColor(activity.status)}`}>
                <activity.icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 mb-1">
                  {activity.title}
                </p>
                <p className="text-xs text-gray-500">{activity.time}</p>
              </div>
              <Badge 
                variant="secondary" 
                className={`text-xs ${getStatusColor(activity.status)}`}
              >
                {getStatusText(activity.status)}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
