// components/overview/StudentOverview.tsx
import { StatsCards } from "./StatsCards";
import { AttendanceChart } from "./AttendanceChart";
import { RecentActivity } from "./RecentActivity";

export function StudentOverview() {
  return (
    <div className="space-y-6">
      <StatsCards role="student" />
      <AttendanceChart />
      <RecentActivity role="student" />
    </div>
  );
}
