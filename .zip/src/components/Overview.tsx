// pages/Overview.tsx or routes/dashboard/Overview.tsx
import { useAuth } from "@/contexts/AuthContext";
import { StudentOverview } from "./Studentoverview";
import { FacultyOverview } from "./Facultyoverview";
import { AdminOverview } from "./Adminoverview";

export default function OverviewPage() {
  const { profile } = useAuth();

  if (!profile) return null;

  switch (profile.role) {
    case "student":
      return <StudentOverview />;
    case "faculty":
      return <FacultyOverview />;
    case "admin":
      return <AdminOverview />;
    default:
      return <div>Invalid role</div>;
  }
}
