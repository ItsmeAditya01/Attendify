// components/overview/AdminOverview.tsx
import { StatsCards } from "./StatsCards";
import { RecentActivity } from "./RecentActivity";

export function AdminOverview() {
  return (
    <div className="space-y-6">
      <StatsCards role="admin" />
      {/* Add system-wide reporting widgets here */}
      <RecentActivity role="admin" />
    </div>
  );
}
