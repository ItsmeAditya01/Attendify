
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Calendar, 
  ClipboardList, 
  TrendingUp,
  BookOpen,
  UserCheck,
  Clock,
  CheckCircle
} from "lucide-react";

interface StatsCardsProps {
  role: string;
}

export function StatsCards({ role }: StatsCardsProps) {
  const getStatsForRole = () => {
    switch (role) {
      case 'student':
        return [
          {
            title: "Total Classes",
            value: "24",
            description: "This semester",
            icon: BookOpen,
            trend: "+2 from last semester",
            color: "text-blue-600"
          },
          {
            title: "Attendance Rate",
            value: "87%",
            description: "Overall percentage",
            icon: CheckCircle,
            trend: "+5% from last month",
            color: "text-green-600"
          },
          {
            title: "Present Days",
            value: "156",
            description: "Out of 180 days",
            icon: Calendar,
            trend: "24 days remaining",
            color: "text-blue-600"
          },
          {
            title: "Upcoming Classes",
            value: "3",
            description: "Today",
            icon: Clock,
            trend: "Next at 10:00 AM",
            color: "text-orange-600"
          }
        ];
      
      case 'faculty':
        return [
          {
            title: "My Classes",
            value: "8",
            description: "Active courses",
            icon: BookOpen,
            trend: "2 new this semester",
            color: "text-blue-600"
          },
          {
            title: "Total Students",
            value: "240",
            description: "Across all classes",
            icon: Users,
            trend: "+15 from last semester",
            color: "text-green-600"
          },
          {
            title: "Avg Attendance",
            value: "82%",
            description: "All classes combined",
            icon: TrendingUp,
            trend: "+3% improvement",
            color: "text-blue-600"
          },
          {
            title: "Classes Today",
            value: "4",
            description: "Remaining",
            icon: Calendar,
            trend: "Next at 11:00 AM",
            color: "text-orange-600"
          }
        ];
      
      case 'admin':
        return [
          {
            title: "Total Users",
            value: "1,247",
            description: "Active in system",
            icon: Users,
            trend: "+52 this month",
            color: "text-blue-600"
          },
          {
            title: "Overall Attendance",
            value: "84%",
            description: "Institution average",
            icon: TrendingUp,
            trend: "+2% from last month",
            color: "text-green-600"
          },
          {
            title: "Active Classes",
            value: "156",
            description: "Currently running",
            icon: ClipboardList,
            trend: "12 new this week",
            color: "text-blue-600"
          },
          {
            title: "Faculty Members",
            value: "89",
            description: "Teaching staff",
            icon: UserCheck,
            trend: "5 new hires",
            color: "text-purple-600"
          }
        ];
      
      default:
        return [];
    }
  };

  const stats = getStatsForRole();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.description}</p>
              </div>
              <div className={`p-3 rounded-full bg-gray-50 ${stat.color}`}>
                <stat.icon className="h-6 w-6" />
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-100">
              <Badge variant="secondary" className="text-xs">
                {stat.trend}
              </Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
